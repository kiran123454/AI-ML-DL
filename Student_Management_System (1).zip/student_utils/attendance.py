# attendance.py - Attendance Calculation

def attendance_percentage(attended, total_classes):
    return round((attended / total_classes) * 100, 2)
