# performance.py - Evaluate Student Performance

def is_passing(grade):
    return grade >= 50
