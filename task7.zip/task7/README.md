# CLI Task Manager

## Overview
A simple command-line task manager that allows users to add, remove, update, and view tasks. Tasks are stored in `tasks.txt` for persistence.

## Features
- Add tasks
- Remove tasks
- Update tasks
- View all tasks
- Tasks persist between program runs

## Installation & Setup
1. Clone the repository:
   ```bash
   git clone <repo-url>
