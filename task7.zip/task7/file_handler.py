import os

def ensure_file_exists(filename):
    """Ensure the tasks file exists."""
    if not os.path.exists(filename):
        with open(filename, 'w') as file:
            pass

def read_tasks(filename):
    """Read tasks from the file and return them as a list."""
    ensure_file_exists(filename)
    with open(filename, 'r') as file:
        return [line.strip() for line in file.readlines()]

def write_tasks(filename, tasks):
    """Write the list of tasks to the file."""
    with open(filename, 'w') as file:
        for task in tasks:
            file.write(task + '\n')
