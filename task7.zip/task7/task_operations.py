from file_handler import read_tasks, write_tasks

def add_task(filename, task):
    """Add a new task to the file."""
    tasks = read_tasks(filename)
    tasks.append(task)
    write_tasks(filename, tasks)
    print("Task added successfully.")

def remove_task(filename, task_number):
    """Remove a task by its number."""
    tasks = read_tasks(filename)
    try:
        removed_task = tasks.pop(task_number - 1)
        write_tasks(filename, tasks)
        print(f"Task '{removed_task}' removed successfully.")
    except IndexError:
        print("Invalid task number.")

def update_task(filename, task_number, new_task):
    """Update an existing task."""
    tasks = read_tasks(filename)
    try:
        tasks[task_number - 1] = new_task
        write_tasks(filename, tasks)
        print("Task updated successfully.")
    except IndexError:
        print("Invalid task number.")

def view_tasks(filename):
    """Display all tasks."""
    tasks = read_tasks(filename)
    if tasks:
        print("\nYour Tasks:")
        for index, task in enumerate(tasks, start=1):
            print(f"{index}. {task}")
    else:
        print("No tasks available.")
